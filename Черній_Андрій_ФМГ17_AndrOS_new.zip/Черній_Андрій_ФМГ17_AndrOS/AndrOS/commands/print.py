import command.command
import os
class Print(command.command.Command):

    def answer(self,argvs,commandManager): 
        print('Welcome to AndrOS ' ,commandManager.commandConfig.get_version())
